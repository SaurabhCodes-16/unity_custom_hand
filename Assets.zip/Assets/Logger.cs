using UnityEngine;
using UnityEngine.XR.Hands;

public class Logger : MonoBehaviour
{
    private XRHandSubsystem handSubsystem;

    void Start()
    {
        var subsystems = new System.Collections.Generic.List<XRHandSubsystem>();
        SubsystemManager.GetSubsystems(subsystems);
        if (subsystems.Count > 0)
            handSubsystem = subsystems[0];
    }

    void Update()
    {
        if (handSubsystem == null) return;

        LogHand(handSubsystem.leftHand, "Left");
        LogHand(handSubsystem.rightHand, "Right");
    }

    void LogHand(XRHand hand, string label)
    {
        if (!hand.isTracked) return;

        LogFinger(hand, XRHandJointID.ThumbTip, "Thumb");
        LogFinger(hand, XRHandJointID.IndexTip, "Index");
        LogFinger(hand, XRHandJointID.MiddleTip, "Middle");
        LogFinger(hand, XRHandJointID.RingTip, "Ring");
        LogFinger(hand, XRHandJointID.LittleTip, "Pinky");
    }

    void LogFinger(XRHand hand, XRHandJointID jointId, string name)
    {
        var joint = hand.GetJoint(jointId);
        if (!joint.TryGetPose(out Pose pose)) return;

        Debug.Log($"{name} Tip: {pose.position}");
    }
}
